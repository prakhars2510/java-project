/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseQueries {

    private static Connection connection;
    private static PreparedStatement addCourse;

    private static PreparedStatement getCourseList;
    private static ResultSet resultSet;

    public static void addCourse(CourseEntry courseEntry) {
        connection = DBConnection.getConnection();
        try {
            addCourse = connection.prepareStatement(
                    "INSERT INTO course (courseCode, description) VALUES (?, ?)"
            );
            addCourse.setString(1, courseEntry.getCourseCode());
            addCourse.setString(2, courseEntry.getDescription());
            addCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static ArrayList<CourseEntry> getCourseList() {
        connection = DBConnection.getConnection();
        ArrayList<CourseEntry> courseList = new ArrayList<CourseEntry>();

        try {
            getCourseList = connection.prepareStatement("SELECT courseCode, description FROM course ORDER BY courseCode");
            resultSet = getCourseList.executeQuery();

            while (resultSet.next()) {
                String code = resultSet.getString("courseCode");
                String desc = resultSet.getString("description");
                courseList.add(new CourseEntry(code, desc));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return courseList;
    }

    public static CourseEntry getCourseByCode(String courseCode) {
        connection = DBConnection.getConnection();
        CourseEntry courseEntry = null;

        try {
            PreparedStatement getCourseByCode = connection.prepareStatement(
                    "SELECT courseCode, description FROM course WHERE courseCode = ?"
            );
            getCourseByCode.setString(1, courseCode);
            resultSet = getCourseByCode.executeQuery();

            if (resultSet.next()) {
                String code = resultSet.getString("courseCode");
                String desc = resultSet.getString("description");
                courseEntry = new CourseEntry(code, desc);
            }

            resultSet.close();
            getCourseByCode.close();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return courseEntry;
    }
}
