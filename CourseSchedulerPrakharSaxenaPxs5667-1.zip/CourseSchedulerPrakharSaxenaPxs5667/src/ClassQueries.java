/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClassQueries {

    private static Connection connection;
    private static PreparedStatement addClass;
    private static PreparedStatement getAllClasses;
    private static PreparedStatement getClassesBySemester;
    private static ResultSet resultSet;
    private static PreparedStatement decrementSeatCount;
    private static PreparedStatement incrementSeatCount;

    public static void addClass(String semester, CourseEntry courseCode, int seats) {
        connection = DBConnection.getConnection();
        try {
            addClass = connection.prepareStatement("INSERT INTO class(semester, coursecode, seats) VALUES (?, ?, ?)");
            addClass.setString(1, semester);
            addClass.setString(2, courseCode.getCourseCode());
            addClass.setInt(3, seats);
            addClass.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    public static void removeClass(String semester, CourseEntry courseCode) {
        connection = DBConnection.getConnection();
        try {
            PreparedStatement removeClass = connection.prepareStatement(
                "DELETE FROM class WHERE semester = ? AND coursecode = ?"
            );
            removeClass.setString(1, semester);
            removeClass.setString(2, courseCode.getCourseCode());
            removeClass.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static ArrayList<ClassEntry> getClassesBySemester(String currentSemester) {
        connection = DBConnection.getConnection();
        ArrayList<ClassEntry> classList = new ArrayList<>();
        ArrayList<CourseEntry> courseList = CourseQueries.getCourseList();

        try {
            getClassesBySemester = connection.prepareStatement("SELECT coursecode, seats FROM class WHERE semester = ?");
            getClassesBySemester.setString(1, currentSemester);
            resultSet = getClassesBySemester.executeQuery();

            while (resultSet.next()) {
                String courseCode = resultSet.getString("coursecode");
                int seats = resultSet.getInt("seats");

                for (CourseEntry course : courseList) {
                    if (course.getCourseCode().equals(courseCode)) {
                        classList.add(new ClassEntry(currentSemester, course, seats));
                        break;
                    }
                }
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return classList;
    }

    public static int getSeats(ClassEntry entry) {
        int seats = -1;
        Connection connection = null;
        PreparedStatement getSeatCount = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            getSeatCount = connection.prepareStatement(
                    "SELECT seats FROM class WHERE semester = ? AND coursecode = ?"
            );
            getSeatCount.setString(1, entry.getSemester());
            getSeatCount.setString(2, entry.getCourseCode().getCourseCode());
            resultSet = getSeatCount.executeQuery();

            if (resultSet.next()) {
                seats = resultSet.getInt("seats");
            } else {
                System.out.println("DEBUG: class not found");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return seats;
    }
    
    public static ArrayList<ClassEntry> getClassesByStudentAndSemester(StudentEntry student, String semester) {
        connection = DBConnection.getConnection();
        ArrayList<ClassEntry> classList = new ArrayList<>();
        ArrayList<CourseEntry> courseList = CourseQueries.getCourseList();

        try {
            PreparedStatement getStudentClasses = connection.prepareStatement(
                "SELECT coursecode FROM schedule WHERE studentid = ? AND semester = ?"
            );
            getStudentClasses.setString(1, student.getStudentID());
            getStudentClasses.setString(2, semester);
            resultSet = getStudentClasses.executeQuery();

            while (resultSet.next()) {
                String courseCode = resultSet.getString("coursecode");

                for (CourseEntry course : courseList) {
                    if (course.getCourseCode().equals(courseCode)) {
                        int seats = getSeats(new ClassEntry(semester, course, 0)); 
                        classList.add(new ClassEntry(semester, course, seats));
                        break;
                    }
                }
            }

            resultSet.close();
            getStudentClasses.close();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return classList;
    }
    
    public static void incrementSeat(ClassEntry entry) {
        connection = DBConnection.getConnection();
        try {
            incrementSeatCount = connection.prepareStatement(
                    "UPDATE class SET seats = seats + 1 WHERE semester = ? AND coursecode = ? AND seats >= 0"
            );
            incrementSeatCount.setString(1, entry.getSemester());
            incrementSeatCount.setString(2, entry.getCourseCode().getCourseCode());
            int updatedRows = incrementSeatCount.executeUpdate();

            if (updatedRows == 0) {
                System.out.println("DEBUG: something happened while incrementing");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static void decrementSeat(ClassEntry entry) {
        connection = DBConnection.getConnection();
        try {
            decrementSeatCount = connection.prepareStatement(
                    "UPDATE class SET seats = seats - 1 WHERE semester = ? AND coursecode = ? AND seats > 0"
            );
            decrementSeatCount.setString(1, entry.getSemester());
            decrementSeatCount.setString(2, entry.getCourseCode().getCourseCode());
            int updatedRows = decrementSeatCount.executeUpdate();

            if (updatedRows == 0) {
                System.out.println("DEBUG: class is full");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
}
