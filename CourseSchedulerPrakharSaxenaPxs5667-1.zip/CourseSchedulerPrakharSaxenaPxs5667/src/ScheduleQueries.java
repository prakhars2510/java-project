/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;


public class ScheduleQueries {

    private static Connection connection;
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudentAndSemester;
    private static PreparedStatement dropScheduleEntry;
    private static ResultSet resultSet;

    public static void addScheduleEntry(ScheduleEntry scheduleEntry) {
        connection = DBConnection.getConnection();
        try {
            addScheduleEntry = connection.prepareStatement(
                "INSERT INTO schedule (semester, courseCode, studentID, status, timestamp) VALUES (?, ?, ?, ?, ?)"
            );
            addScheduleEntry.setString(1, scheduleEntry.getSemester());
            addScheduleEntry.setString(2, scheduleEntry.getCourseCode().getCourseCode());
            addScheduleEntry.setString(3, scheduleEntry.getStudentID().getStudentID());
            addScheduleEntry.setString(4, scheduleEntry.getStatus());
            addScheduleEntry.setTimestamp(5, scheduleEntry.getTimestamp());
            addScheduleEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static ArrayList<ScheduleEntry> getScheduleByStudentAndSemester(String semester, StudentEntry st) {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduleList = new ArrayList<>();

        try {
            getScheduleByStudentAndSemester = connection.prepareStatement(
                "SELECT courseCode, status, timestamp FROM schedule WHERE studentID = ? AND semester = ?"
            );
            getScheduleByStudentAndSemester.setString(1, st.getStudentID());
            getScheduleByStudentAndSemester.setString(2, semester);
            resultSet = getScheduleByStudentAndSemester.executeQuery();

            while (resultSet.next()) {
                String courseCode = resultSet.getString("courseCode");
                String status = resultSet.getString("status");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");

                CourseEntry course = new CourseEntry(courseCode, "");
                StudentEntry student = new StudentEntry(st.getStudentID(), "", "");

                scheduleList.add(new ScheduleEntry(semester, course, student, status, timestamp));
            }

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return scheduleList;
    }
    
    public static void dropScheduleEntry(String semester, ClassEntry classEntry, StudentEntry studentEntry) {
        connection = DBConnection.getConnection();

        try {
            dropScheduleEntry = connection.prepareStatement(
                "DELETE FROM schedule WHERE semester = ? AND courseCode = ? AND studentID = ?"
            );
            dropScheduleEntry.setString(1, semester);
            dropScheduleEntry.setString(2, classEntry.getCourseCode().getCourseCode());
            dropScheduleEntry.setString(3, studentEntry.getStudentID());
            dropScheduleEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    public static boolean isWaitlisted(String semester, ClassEntry classEntry, StudentEntry studentEntry) {
        connection = DBConnection.getConnection();
        ResultSet resultSet = null;
        try {
            PreparedStatement checkWaitlist = connection.prepareStatement(
                "SELECT status FROM schedule WHERE semester = ? AND courseCode = ? AND studentID = ?"
            );
            checkWaitlist.setString(1, semester);
            checkWaitlist.setString(2, classEntry.getCourseCode().getCourseCode());
            checkWaitlist.setString(3, studentEntry.getStudentID());
            resultSet = checkWaitlist.executeQuery();

            if (resultSet.next()) {
                String status = resultSet.getString("status");
                return status.equalsIgnoreCase("W");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
            } catch (SQLException ignored) {}
        }
        return false;
    }
}
