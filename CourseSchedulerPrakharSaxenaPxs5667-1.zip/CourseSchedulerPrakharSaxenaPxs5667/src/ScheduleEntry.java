/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
import java.sql.Timestamp;

public class ScheduleEntry {
    private String semester;
    private CourseEntry courseCode;
    private StudentEntry studentID;
    private String status;
    private Timestamp timestamp;

    public ScheduleEntry(String semester, CourseEntry courseCode, StudentEntry studentID, String status, Timestamp timestamp) {
        this.semester = semester;
        this.courseCode = courseCode;
        this.studentID = studentID;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getSemester() {
        return semester;
    }

    public CourseEntry getCourseCode() {
        return courseCode;
    }

    public StudentEntry getStudentID() {
        return studentID;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }
}