/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StudentQueries {
    private static Connection connection;
    private static PreparedStatement addStudent;
    private static PreparedStatement getStudentList;
    private static ResultSet resultSet;
    
    public static void addStudent(StudentEntry student) {
        connection = DBConnection.getConnection();
        try {
            addStudent = connection.prepareStatement("insert into student (studentid, firstname, lastname) values (?, ?, ?)");
            addStudent.setString(1, student.getStudentID());
            addStudent.setString(2, student.getFirstName());
            addStudent.setString(3, student.getLastName());
            addStudent.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    public static void removeStudent(StudentEntry student) {
        connection = DBConnection.getConnection();
        try {
            PreparedStatement removeStudent = connection.prepareStatement(
                "DELETE FROM student WHERE studentid = ?"
            );
            removeStudent.setString(1, student.getStudentID());
            int rowsAffected = removeStudent.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No student found with ID: " + student.getStudentID());
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    public static ArrayList<StudentEntry> getStudentList() {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try {
            getStudentList = connection.prepareStatement("select studentid, firstname, lastname from student order by lastname, firstname");
            resultSet = getStudentList.executeQuery();
            
            while (resultSet.next()) {
                String studentID = resultSet.getString("studentid");
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");
                students.add(new StudentEntry(studentID, firstName, lastName));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return students;
    }
    
    public static StudentEntry getStudentByID(String studentID) {
        connection = DBConnection.getConnection();
        StudentEntry studentEntry = null;

        try {
            PreparedStatement getStudentByID = connection.prepareStatement(
                    "SELECT studentid, firstname, lastname FROM student WHERE studentid = ?"
            );
            getStudentByID.setString(1, studentID);
            resultSet = getStudentByID.executeQuery();

            if (resultSet.next()) {
                String id = resultSet.getString("studentid");
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");
                studentEntry = new StudentEntry(id, firstName, lastName);
            }

            resultSet.close();
            getStudentByID.close();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return studentEntry;
    }
    
    public static ArrayList<StudentEntry> getStudentsByClass(ClassEntry classEntry, String status) {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> waitlistedStudents = new ArrayList<>();

        try {
            PreparedStatement getWaitlisted = connection.prepareStatement(
                "SELECT s.studentid, s.firstname, s.lastname " +
                "FROM schedule sch " +
                "JOIN student s ON sch.studentid = s.studentid " +
                "WHERE sch.semester = ? AND sch.coursecode = ? AND sch.status = '" + status + "' " +
                "ORDER BY sch.timestamp"
            );
            getWaitlisted.setString(1, classEntry.getSemester());
            getWaitlisted.setString(2, classEntry.getCourseCode().getCourseCode());

            resultSet = getWaitlisted.executeQuery();

            while (resultSet.next()) {
                String studentID = resultSet.getString("studentid");
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");
                waitlistedStudents.add(new StudentEntry(studentID, firstName, lastName));
            }

            resultSet.close();
            getWaitlisted.close();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return waitlistedStudents;
    }
    
    public static void dropClass(StudentEntry student, ClassEntry classEntry) {
        connection = DBConnection.getConnection();
        try {
            PreparedStatement dropClass = connection.prepareStatement(
                "DELETE FROM schedule WHERE studentid = ? AND semester = ? AND coursecode = ?"
            );
            dropClass.setString(1, student.getStudentID());
            dropClass.setString(2, classEntry.getSemester());
            dropClass.setString(3, classEntry.getCourseCode().getCourseCode());
            int rowsAffected = dropClass.executeUpdate();

            if (rowsAffected > 0) {
            } else {
                System.out.println("DEBUG: Student was not enrolled in the class");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
   
}




